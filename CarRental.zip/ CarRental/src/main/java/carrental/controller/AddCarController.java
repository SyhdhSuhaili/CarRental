package carrental.controller;

import carrental.dao.CarDAO;
import carrental.model.Car;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@MultipartConfig
public class AddCarController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String jdbcURL = "jdbc:mysql://localhost:3306/car_rental";
        String dbUser = "root";
        String dbPassword = "";

        String brand = request.getParameter("brand");
        String model = request.getParameter("model");
        String type = request.getParameter("type");
        int seats = Integer.parseInt(request.getParameter("seats"));
        String transmission = request.getParameter("transmission");
        boolean airConditioning = request.getParameter("airConditioning").equals("yes");
        Part filePart = request.getPart("image");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String image = fileName;
        String status = request.getParameter("status");
        double pricePerDay = Double.parseDouble(request.getParameter("pricePerDay"));

        // Save the uploaded file
        String uploadPath = getServletContext().getRealPath("") + File.separator + "images";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();
        filePart.write(uploadPath + File.separator + fileName);

        Car newCar = new Car(0, brand, model, type, seats, transmission, airConditioning, image, pricePerDay, status);

        try {
            // Load the MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
            CarDAO carDAO = new CarDAO();
            carDAO.insertCar(connection, newCar);
            connection.close();
            response.sendRedirect("car-list.jsp");
        } catch (ClassNotFoundException | SQLException e) {
            throw new ServletException(e);
        }
    }
}
