package carrental.controller;

import carrental.dao.ReservationDAO;
import carrental.model.Reservation;
import carrental.connection.ConnectionManager;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class BookingController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String customerName = request.getParameter("customerName");
        String carBrand = request.getParameter("carBrand");
        String carModel = request.getParameter("carModel");
        String pickupDate = request.getParameter("pickupDate");
        String dropoffDate = request.getParameter("dropoffDate");
        double totalPrice = Double.parseDouble(request.getParameter("totalPrice"));

        Reservation reservation = new Reservation();
        reservation.setCustomerName(customerName);
        reservation.setCarBrand(carBrand);
        reservation.setCarModel(carModel);
        reservation.setPickupDate(pickupDate);
        reservation.setDropoffDate(dropoffDate);
        reservation.setTotalPrice(totalPrice);

        try (Connection conn = ConnectionManager.getConnection()) {
            ReservationDAO reservationDAO = new ReservationDAO();
            reservationDAO.insertReservation(conn, reservation);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.sendRedirect("reservationList.jsp");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().write("GET method is not supported.");
    }
}
