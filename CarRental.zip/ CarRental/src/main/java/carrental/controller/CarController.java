package carrental.controller;

import carrental.dao.CarDAO;
import carrental.model.Car;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CarController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/car_rental";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String brand = request.getParameter("brand");
        String model = request.getParameter("model");
        String type = request.getParameter("type");
        int seats;
        String transmission = request.getParameter("transmission");
        boolean airConditioning = request.getParameter("airConditioning") != null;
        String image = request.getParameter("image");
        double pricePerDay;
        String status = request.getParameter("status");

        // Validate form inputs
        try {
            seats = Integer.parseInt(request.getParameter("seats"));
            pricePerDay = Double.parseDouble(request.getParameter("pricePerDay"));
        } catch (NumberFormatException e) {
            throw new ServletException("Invalid input for seats or pricePerDay", e);
        }

        Car newCar = new Car(0, brand, model, type, seats, transmission, airConditioning, image, pricePerDay, status);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // Ensure the JDBC driver is loaded
            try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
                CarDAO carDAO = new CarDAO();
                carDAO.insertCar(connection, newCar);
                response.sendRedirect("listCars");
            }
        } catch (ClassNotFoundException e) {
            throw new ServletException("MySQL JDBC Driver not found", e);
        } catch (SQLException e) {
            throw new ServletException("Database access error", e);
        }
    }
}
