package carrental.controller;

import carrental.dao.CarDAO;
import carrental.connection.ConnectionManager;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class DeleteCarController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        CarDAO carDAO = new CarDAO();

        try (Connection conn = ConnectionManager.getConnection()) {
            carDAO.deleteCar(conn, id);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.sendRedirect("car-list.jsp");
    }
}
