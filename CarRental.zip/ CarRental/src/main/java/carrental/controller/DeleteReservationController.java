package carrental.controller;

import carrental.dao.ReservationDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class DeleteReservationController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        ReservationDAO reservationDAO = new ReservationDAO();

        try {
            reservationDAO.deleteReservation(id);
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("reservationList.jsp");
    }
}