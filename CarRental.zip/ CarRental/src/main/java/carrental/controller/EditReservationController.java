package carrental.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class EditReservationController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String carBrand = request.getParameter("carBrand");
        String carModel = request.getParameter("carModel");
        String pickupLocation = request.getParameter("pickupLocation");
        String pickupDate = request.getParameter("pickupDate");
        String dropoffDate = request.getParameter("dropoffDate");
        String customerName = request.getParameter("customerName");
        String customerIC = request.getParameter("customerIC");
        String customerEmail = request.getParameter("customerEmail");

        // Database connection parameters
        String jdbcURL = "jdbc:mysql://localhost:3306/car_rental";
        String dbUser = "root";
        String dbPassword = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = "UPDATE reservations SET car_brand = ?, car_model = ?, pickup_location = ?, pickup_date = ?, dropoff_date = ?, customer_name = ?, customer_ic = ?, customer_email = ? WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, carBrand);
            statement.setString(2, carModel);
            statement.setString(3, pickupLocation);
            statement.setString(4, pickupDate);
            statement.setString(5, dropoffDate);
            statement.setString(6, customerName);
            statement.setString(7, customerIC);
            statement.setString(8, customerEmail);
            statement.setInt(9, Integer.parseInt(request.getParameter("id"))); // Get the reservation ID from the form

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                response.getWriter().write("Reservation updated successfully!");
            } else {
                response.getWriter().write("Error updating reservation.");
            }

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Database error: " + e.getMessage());
        }
    }
}
