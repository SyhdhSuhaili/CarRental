package carrental.controller;

import carrental.dao.CarDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class GetCarBrandsController extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        CarDAO carDAO = new CarDAO();
        List<String> carBrands = null;

        try {
            carBrands = carDAO.getAllCarBrands();
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.print("[");
        for (int i = 0; i < carBrands.size(); i++) {
            out.print("\"" + carBrands.get(i) + "\"");
            if (i < carBrands.size() - 1) {
                out.print(",");
            }
        }
        out.print("]");
    }
}
