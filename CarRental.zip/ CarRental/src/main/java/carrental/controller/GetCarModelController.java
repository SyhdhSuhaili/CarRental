package carrental.controller;

import carrental.dao.CarDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class GetCarModelController extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        String brand = request.getParameter("brand");
        CarDAO carDAO = new CarDAO();
        List<String> carModels = null;

        try {
            carModels = carDAO.getCarModelsByBrand(brand);
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.print("[");
        for (int i = 0; i < carModels.size(); i++) {
            out.print("\"" + carModels.get(i) + "\"");
            if (i < carModels.size() - 1) {
                out.print(",");
            }
        }
        out.print("]");
    }
}
