package carrental.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class LoadReservationController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String jdbcURL = "jdbc:mysql://localhost:3306/car_rental";
        String dbUser = "root";
        String dbPassword = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = "SELECT r.id, r.customer_name, r.pickup_date, r.dropoff_date, r.customer_phone, r.total_price, r.total_days, r.payment_status, c.brand, c.model " +
                         "FROM reservations r " +
                         "JOIN cars c ON r.car_id = c.id " +
                         "ORDER BY r.id DESC LIMIT 5";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            System.out.println("Query executed successfully!");

            while (resultSet.next()) {
                System.out.println("Data: " + resultSet.getString("customer_name") + ", " + resultSet.getString("brand") + " " + resultSet.getString("model"));
                out.println("<tr>");
                out.println("<td>" + resultSet.getString("customer_name") + "</td>");
                out.println("<td>" + resultSet.getString("brand") + " " + resultSet.getString("model") + "</td>");
                out.println("<td>" + resultSet.getDate("pickup_date") + "</td>");
                out.println("<td>" + resultSet.getDate("dropoff_date") + "</td>");
                out.println("<td>" + resultSet.getString("customer_phone") + "</td>");
                out.println("<td>$" + resultSet.getDouble("total_price") + "</td>");
                out.println("<td>" + resultSet.getInt("total_days") + "</td>");
                out.println("<td>" + resultSet.getString("payment_status") + "</td>");
                out.println("<td>");
                out.println("<a href='editReservation.jsp?id=" + resultSet.getInt("id") + "' class='btn btn-primary btn-sm'>Edit</a>");
                out.println("<a href='deleteReservation?id=" + resultSet.getInt("id") + "' class='btn btn-danger btn-sm'>Delete</a>");
                out.println("</td>");
                out.println("</tr>");
            }

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<tr><td colspan='9'>An error occurred while loading the bookings.</td></tr>");
        }
    }
}
