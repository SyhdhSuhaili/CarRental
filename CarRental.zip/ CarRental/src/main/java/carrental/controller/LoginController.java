package carrental.controller;

import carrental.connection.ConnectionManager;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM admins WHERE username = ? AND password = ?")) {
            statement.setString(1, username);
            statement.setString(2, password);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("adminUsername", username);
                    response.sendRedirect("dashboard.jsp");
                } else {
                    response.sendRedirect("adminLogin.jsp?error=Invalid username or password");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("adminLogin.jsp?error=An error occurred. Please try again.");
        }
    }
}


