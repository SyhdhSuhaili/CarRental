package carrental.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PaymentController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public PaymentController() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String carId = request.getParameter("carId");
        String carPricePerDay = request.getParameter("carPricePerDay");
        String totalDays = request.getParameter("totalDays");
        String totalPrice = request.getParameter("totalPrice");
        String pickupLocation = request.getParameter("pickupLocation");
        String pickupDate = request.getParameter("pickupDate");
        String dropoffDate = request.getParameter("dropoffDate");
        String name = request.getParameter("name");
        String customerIc = request.getParameter("customer_ic");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String customerAddress = request.getParameter("customer_address");
        String paymentMethod = request.getParameter("paymentMethod");

        // Determine payment status based on payment method
        String paymentStatus = "Booked";
        if ("Cash".equalsIgnoreCase(paymentMethod)) {
            paymentStatus = "Pending";
        }

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish the connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_rental", "root", "");
            
            // Prepare the SQL statement
            String sql = "INSERT INTO reservations (car_id, pickup_location, pickup_date, dropoff_date, customer_name, customer_ic, customer_email, customer_phone, customer_address, payment_method, total_price, car_price_per_day, total_days, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, carId);
            preparedStatement.setString(2, pickupLocation);
            preparedStatement.setString(3, pickupDate);
            preparedStatement.setString(4, dropoffDate);
            preparedStatement.setString(5, name);
            preparedStatement.setString(6, customerIc);
            preparedStatement.setString(7, email);
            preparedStatement.setString(8, phone);
            preparedStatement.setString(9, customerAddress);
            preparedStatement.setString(10, paymentMethod);
            preparedStatement.setString(11, totalPrice);
            preparedStatement.setString(12, carPricePerDay);
            preparedStatement.setString(13, totalDays);
            preparedStatement.setString(14, paymentStatus);
            
            // Execute the SQL statement
            preparedStatement.executeUpdate();

            // Set request attributes to forward to confirmation page
            request.setAttribute("carId", carId);
            request.setAttribute("carPricePerDay", carPricePerDay);
            request.setAttribute("totalDays", totalDays);
            request.setAttribute("totalPrice", totalPrice);
            request.setAttribute("pickupLocation", pickupLocation);
            request.setAttribute("pickupDate", pickupDate);
            request.setAttribute("dropoffDate", dropoffDate);
            request.setAttribute("name", name);
            request.setAttribute("customerIc", customerIc);
            request.setAttribute("email", email);
            request.setAttribute("phone", phone);
            request.setAttribute("customerAddress", customerAddress);
            request.setAttribute("paymentMethod", paymentMethod);
            request.setAttribute("paymentStatus", paymentStatus);

            // Forward to confirmation page
            request.getRequestDispatcher("reservationConfirmation.jsp").forward(request, response);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new ServletException(e);
        } finally {
            // Close the resources
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
