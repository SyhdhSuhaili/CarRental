package carrental.controller;

import carrental.dao.UserDAO;
import carrental.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;


public class RegisterController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        User newUser = new User(username, password, email);

        UserDAO userDAO = new UserDAO();
        try {
            userDAO.registerUser(newUser);
            response.sendRedirect("adminLogin.jsp"); // Redirect to login page after successful registration
        } catch (SQLException e) {
            throw new ServletException("User registration failed", e);
        }
    }
}
