package carrental.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ReservationController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ReservationController() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("create".equalsIgnoreCase(action)) {
            createReservation(request, response);
        } else if ("edit".equalsIgnoreCase(action)) {
            editReservation(request, response);
        } else if ("delete".equalsIgnoreCase(action)) {
            deleteReservation(request, response);
        }
    }

    private void createReservation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String carId = request.getParameter("carId");
        String pickupLocation = request.getParameter("pickupLocation");
        String pickupDate = request.getParameter("pickupDate");
        String dropoffDate = request.getParameter("dropoffDate");
        String name = request.getParameter("name");
        String customerIc = request.getParameter("customerIc");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String customerAddress = request.getParameter("customerAddress");
        String paymentMethod = request.getParameter("paymentMethod");

        String paymentStatus = paymentMethod.equals("Cash") ? "Pending" : "Paid";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_rental", "root", "");

            // Insert the reservation into the database
            String insertReservationSQL = "INSERT INTO reservations (car_id, pickup_location, pickup_date, dropoff_date, customer_name, customer_ic, customer_email, customer_phone, customer_address, payment_method, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(insertReservationSQL);
            preparedStatement.setInt(1, Integer.parseInt(carId));
            preparedStatement.setString(2, pickupLocation);
            preparedStatement.setString(3, pickupDate);
            preparedStatement.setString(4, dropoffDate);
            preparedStatement.setString(5, name);
            preparedStatement.setString(6, customerIc);
            preparedStatement.setString(7, email);
            preparedStatement.setString(8, phone);
            preparedStatement.setString(9, customerAddress);
            preparedStatement.setString(10, paymentMethod);
            preparedStatement.setString(11, paymentStatus);

            preparedStatement.executeUpdate();

            // Redirect to confirmation page
            response.sendRedirect("reservationConfirmation.jsp");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new ServletException(e);
        } finally {
            // Close the resources
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void editReservation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String carId = request.getParameter("carId");
        String pickupLocation = request.getParameter("pickupLocation");
        String pickupDate = request.getParameter("pickupDate");
        String dropoffDate = request.getParameter("dropoffDate");
        String name = request.getParameter("name");
        String customerIc = request.getParameter("customerIc");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String customerAddress = request.getParameter("customerAddress");
        String paymentMethod = request.getParameter("paymentMethod");
        String paymentStatus = paymentMethod.equals("Cash") ? "Pending" : "Paid";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_rental", "root", "");

            // Update the reservation in the database
            String updateReservationSQL = "UPDATE reservations SET car_id = ?, pickup_location = ?, pickup_date = ?, dropoff_date = ?, customer_name = ?, customer_ic = ?, customer_email = ?, customer_phone = ?, customer_address = ?, payment_method = ?, payment_status = ? WHERE id = ?";
            preparedStatement = connection.prepareStatement(updateReservationSQL);
            preparedStatement.setInt(1, Integer.parseInt(carId));
            preparedStatement.setString(2, pickupLocation);
            preparedStatement.setString(3, pickupDate);
            preparedStatement.setString(4, dropoffDate);
            preparedStatement.setString(5, name);
            preparedStatement.setString(6, customerIc);
            preparedStatement.setString(7, email);
            preparedStatement.setString(8, phone);
            preparedStatement.setString(9, customerAddress);
            preparedStatement.setString(10, paymentMethod);
            preparedStatement.setString(11, paymentStatus);
            preparedStatement.setInt(12, id);

            preparedStatement.executeUpdate();

            // Redirect to confirmation page
            response.sendRedirect("dashboard.jsp");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new ServletException(e);
        } finally {
            // Close the resources
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void deleteReservation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_rental", "root", "");

            // Delete the reservation from the database
            String deleteReservationSQL = "DELETE FROM reservations WHERE id = ?";
            preparedStatement = connection.prepareStatement(deleteReservationSQL);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

            // Redirect to the dashboard
            response.sendRedirect("dashboard.jsp");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new ServletException(e);
        } finally {
            // Close the resources
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
