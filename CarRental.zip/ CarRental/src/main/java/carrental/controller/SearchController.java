package carrental.controller;

import carrental.dao.CarDAO;
import carrental.model.Car;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class SearchController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/car_rental";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String carBrand = request.getParameter("carBrand");
        String pickupLocation = request.getParameter("pickupLocation");
        String pickupDateStr = request.getParameter("pickupDate");
        String dropoffDateStr = request.getParameter("dropoffDate");
        int currentPage = 1;
        int recordsPerPage = 10;

        if (request.getParameter("page") != null) {
            try {
                currentPage = Integer.parseInt(request.getParameter("page"));
            } catch (NumberFormatException e) {
                currentPage = 1;
            }
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // Ensure the JDBC driver is loaded
            try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
                CarDAO carDAO = new CarDAO();

                // Adjust the brand parameter to handle "Any"
                String adjustedCarBrand = "Any".equals(carBrand) ? "" : carBrand;

                List<Car> cars = carDAO.selectFilteredCars(connection, adjustedCarBrand, pickupLocation, pickupDateStr, dropoffDateStr, currentPage, recordsPerPage);
                int totalRecords = carDAO.getNumberOfRows(connection, adjustedCarBrand);
                int totalPages = (int) Math.ceil((double) totalRecords / recordsPerPage);

                // Calculate total days
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date pickupDate = sdf.parse(pickupDateStr);
                Date dropoffDate = sdf.parse(dropoffDateStr);
                long diffInMillies = Math.abs(dropoffDate.getTime() - pickupDate.getTime());
                long totalDays = diffInMillies / (24 * 60 * 60 * 1000);

                // Set attributes for JSP
                request.setAttribute("cars", cars);
                request.setAttribute("carBrand", carBrand);
                request.setAttribute("pickupLocation", pickupLocation);
                request.setAttribute("pickupDate", pickupDateStr);
                request.setAttribute("dropoffDate", dropoffDateStr);
                request.setAttribute("currentPage", currentPage);
                request.setAttribute("totalPages", totalPages);
                request.setAttribute("totalDays", totalDays);

                RequestDispatcher dispatcher = request.getRequestDispatcher("results.jsp");
                dispatcher.forward(request, response);
            }
        } catch (ClassNotFoundException e) {
            throw new ServletException("MySQL JDBC Driver not found", e);
        } catch (SQLException | ParseException e) {
            throw new ServletException("Database access error", e);
        }
    }
}
