package carrental.controller;

import carrental.connection.ConnectionManager;
import carrental.dao.CarDAO;
import carrental.model.Car;
import java.io.IOException;
import java.sql.Connection;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UpdateCarController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String brand = request.getParameter("brand");
        String model = request.getParameter("model");
        String type = request.getParameter("type");
        int seats = Integer.parseInt(request.getParameter("seats"));
        String transmission = request.getParameter("transmission");
        boolean airConditioning = request.getParameter("air_conditioning") != null;
        String image = request.getParameter("image");
        double pricePerDay = Double.parseDouble(request.getParameter("price_per_day"));
        String status = request.getParameter("status");

        Car car = new Car(id, brand, model, type, seats, transmission, airConditioning, image, pricePerDay, status);

        Connection conn = null;
        try {
            conn = ConnectionManager.getConnection();
            CarDAO carDAO = new CarDAO();
            carDAO.updateCar(conn, car);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ConnectionManager.closeConnection(conn);
        }

        response.sendRedirect("car-list.jsp");
    }
}
