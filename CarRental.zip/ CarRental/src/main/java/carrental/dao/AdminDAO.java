package carrental.dao;

import carrental.connection.ConnectionManager;
import carrental.model.Admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDAO {

    public Admin authenticateAdmin(String username, String password) throws SQLException {
        String sql = "SELECT * FROM admins WHERE username = ? AND password = ?";

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return new Admin(resultSet.getInt("id"), resultSet.getString("username"), resultSet.getString("password"));
            } else {
                return null;
            }
        }
    }

	public void registerUser(String username, String password, String email) {
		// TODO Auto-generated method stub
		
	}
}
