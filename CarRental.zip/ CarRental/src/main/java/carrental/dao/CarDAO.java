package carrental.dao;

import carrental.model.Car;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CarDAO {

    // Method to select a car by ID
    public Car selectCar(Connection conn, int id) throws SQLException {
        String sql = "SELECT * FROM cars WHERE id = ?";
        Car car = null;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    car = new Car(
                        rs.getInt("id"),
                        rs.getString("brand"),
                        rs.getString("model"),
                        rs.getString("type"),
                        rs.getInt("seats"),
                        rs.getString("transmission"),
                        rs.getBoolean("air_conditioning"),
                        rs.getString("image"),
                        rs.getDouble("price_per_day"),
                        rs.getString("status")
                    );
                }
            }
        }

        return car;
    }

    // Method to select all cars
    public List<Car> selectAllCars(Connection conn) throws SQLException {
        String sql = "SELECT * FROM cars";
        List<Car> cars = new ArrayList<>();

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Car car = new Car(
                    rs.getInt("id"),
                    rs.getString("brand"),
                    rs.getString("model"),
                    rs.getString("type"),
                    rs.getInt("seats"),
                    rs.getString("transmission"),
                    rs.getBoolean("air_conditioning"),
                    rs.getString("image"),
                    rs.getDouble("price_per_day"),
                    rs.getString("status")
                );
                cars.add(car);
            }
        }

        return cars;
    }

    // Method to insert a new car
    public void insertCar(Connection conn, Car car) throws SQLException {
        String sql = "INSERT INTO cars (brand, model, type, seats, transmission, air_conditioning, image, price_per_day, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, car.getBrand());
            ps.setString(2, car.getModel());
            ps.setString(3, car.getType());
            ps.setInt(4, car.getSeats());
            ps.setString(5, car.getTransmission());
            ps.setBoolean(6, car.isAirConditioning());
            ps.setString(7, car.getImage());
            ps.setDouble(8, car.getPricePerDay());
            ps.setString(9, car.getStatus());
            ps.executeUpdate();
        }
    }

    // Method to update an existing car
    public void updateCar(Connection conn, Car car) throws SQLException {
        String sql = "UPDATE cars SET brand = ?, model = ?, type = ?, seats = ?, transmission = ?, air_conditioning = ?, image = ?, price_per_day = ?, status = ? WHERE id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, car.getBrand());
            ps.setString(2, car.getModel());
            ps.setString(3, car.getType());
            ps.setInt(4, car.getSeats());
            ps.setString(5, car.getTransmission());
            ps.setBoolean(6, car.isAirConditioning());
            ps.setString(7, car.getImage());
            ps.setDouble(8, car.getPricePerDay());
            ps.setString(9, car.getStatus());
            ps.setInt(10, car.getId());
            ps.executeUpdate();
        }
    }

    // Method to delete a car by ID
    public void deleteCar(Connection conn, int id) throws SQLException {
        String sql = "DELETE FROM cars WHERE id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    // Method to select filtered cars
    public List<Car> selectFilteredCars(Connection conn, String brand, String pickupLocation, String pickupDate, String dropoffDate, int page, int recordsPerPage) throws SQLException {
        String sql = "SELECT * FROM cars WHERE brand LIKE ? LIMIT ?, ?";
        List<Car> cars = new ArrayList<>();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + brand + "%");
            ps.setInt(2, (page - 1) * recordsPerPage);
            ps.setInt(3, recordsPerPage);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Car car = new Car(
                        rs.getInt("id"),
                        rs.getString("brand"),
                        rs.getString("model"),
                        rs.getString("type"),
                        rs.getInt("seats"),
                        rs.getString("transmission"),
                        rs.getBoolean("air_conditioning"),
                        rs.getString("image"),
                        rs.getDouble("price_per_day"),
                        rs.getString("status")
                    );
                    cars.add(car);
                }
            }
        }

        return cars;
    }

    // Method to get the number of rows for filtered cars
    public int getNumberOfRows(Connection conn, String brand) throws SQLException {
        String sql = "SELECT COUNT(*) FROM cars WHERE brand LIKE ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + brand + "%");
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }

    // Method to get all unique car brands
    public List<String> getAllCarBrands(Connection conn) throws SQLException {
        String sql = "SELECT DISTINCT brand FROM cars";
        List<String> carBrands = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                carBrands.add(rs.getString("brand"));
            }
        }
        return carBrands;
    }

    // Method to get car models by brand
    public List<String> getCarModelsByBrand(Connection conn, String brand) throws SQLException {
        String sql = "SELECT DISTINCT model FROM cars WHERE brand = ?";
        List<String> carModels = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, brand);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    carModels.add(rs.getString("model"));
                }
            }
        }
        return carModels;
    }
}
