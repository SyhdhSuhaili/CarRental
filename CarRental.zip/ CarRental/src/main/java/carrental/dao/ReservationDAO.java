package carrental.dao;

import carrental.connection.ConnectionManager;
import carrental.model.DashboardStats;
import carrental.model.Reservation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ReservationDAO {

    public DashboardStats getDashboardStats() throws SQLException {
        String sql = "SELECT (SELECT COUNT(*) FROM cars) AS availableCars, " +
                     "(SELECT COUNT(*) FROM reservations WHERE pickup_date >= CURRENT_DATE) AS bookedCars, " +
                     "(SELECT COUNT(DISTINCT customer_email) FROM reservations) AS totalCustomers";

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            if (resultSet.next()) {
                return new DashboardStats(
                        resultSet.getInt("availableCars"),
                        resultSet.getInt("bookedCars"),
                        resultSet.getInt("totalCustomers")
                );
            }
            return null;
        }
    }

    public List<Reservation> getLastReservations() throws SQLException {
        List<Reservation> reservations = new ArrayList<>();
        String sql = "SELECT r.id, r.car_id, r.pickup_location, r.pickup_date, r.dropoff_date, " +
                     "r.customer_name, r.customer_ic, r.customer_email, r.customer_phone, r.customer_address, " +
                     "r.payment_status, r.total_price, r.car_price_per_day, r.total_days " +
                     "FROM reservations r " +
                     "ORDER BY r.pickup_date DESC LIMIT 5";

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                reservations.add(new Reservation(
                        resultSet.getInt("id"),
                        resultSet.getInt("car_id"),
                        resultSet.getString("pickup_location"),
                        resultSet.getDate("pickup_date"),
                        resultSet.getDate("dropoff_date"),
                        resultSet.getString("customer_name"),
                        resultSet.getString("customer_ic"),
                        resultSet.getString("customer_email"),
                        resultSet.getString("customer_phone"),
                        resultSet.getString("customer_address"),
                        resultSet.getString("payment_status"),
                        resultSet.getDouble("total_price"),
                        resultSet.getDouble("car_price_per_day"),
                        resultSet.getInt("total_days")
                ));
            }
            return reservations;
        }
    }

    public List<Reservation> selectAllReservations() throws SQLException {
        List<Reservation> reservations = new ArrayList<>();
        String sql = "SELECT id, car_id, pickup_location, pickup_date, dropoff_date, customer_name, customer_ic, customer_email, customer_phone, customer_address, payment_status, total_price, car_price_per_day, total_days FROM reservations";

        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Reservation reservation = new Reservation(
                    rs.getInt("id"),
                    rs.getInt("car_id"),
                    rs.getString("pickup_location"),
                    rs.getDate("pickup_date"),
                    rs.getDate("dropoff_date"),
                    rs.getString("customer_name"),
                    rs.getString("customer_ic"),
                    rs.getString("customer_email"),
                    rs.getString("customer_phone"),
                    rs.getString("customer_address"),
                    rs.getString("payment_status"),
                    rs.getDouble("total_price"),
                    rs.getDouble("car_price_per_day"),
                    rs.getInt("total_days")
                );
                reservations.add(reservation);
            }
        }
        return reservations;
    }

    public boolean insertReservation(Reservation reservation) throws SQLException {
        String sql = "INSERT INTO reservations (car_id, pickup_location, pickup_date, dropoff_date, " +
                     "customer_name, customer_ic, customer_email, customer_phone, customer_address, " +
                     "payment_status, total_price, car_price_per_day, total_days) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, reservation.getCarId());
            preparedStatement.setString(2, reservation.getPickupLocation());
            preparedStatement.setDate(3, new java.sql.Date(reservation.getPickupDate().getTime()));
            preparedStatement.setDate(4, new java.sql.Date(reservation.getDropoffDate().getTime()));
            preparedStatement.setString(5, reservation.getCustomerName());
            preparedStatement.setString(6, reservation.getCustomerIC());
            preparedStatement.setString(7, reservation.getCustomerEmail());
            preparedStatement.setString(8, reservation.getCustomerPhone());
            preparedStatement.setString(9, reservation.getCustomerAddress());
            preparedStatement.setString(10, reservation.getPaymentStatus());
            preparedStatement.setDouble(11, reservation.getTotalPrice());
            preparedStatement.setDouble(12, reservation.getCarPricePerDay());
            preparedStatement.setInt(13, reservation.getTotalDays());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        }
    }

    public boolean updateReservation(Reservation reservation) throws SQLException {
        String sql = "UPDATE reservations SET car_id = ?, pickup_location = ?, pickup_date = ?, dropoff_date = ?, " +
                     "customer_name = ?, customer_ic = ?, customer_email = ?, customer_phone = ?, customer_address = ?, " +
                     "payment_status = ?, total_price = ?, car_price_per_day = ?, total_days = ? WHERE id = ?";

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, reservation.getCarId());
            preparedStatement.setString(2, reservation.getPickupLocation());
            preparedStatement.setDate(3, new java.sql.Date(reservation.getPickupDate().getTime()));
            preparedStatement.setDate(4, new java.sql.Date(reservation.getDropoffDate().getTime()));
            preparedStatement.setString(5, reservation.getCustomerName());
            preparedStatement.setString(6, reservation.getCustomerIC());
            preparedStatement.setString(7, reservation.getCustomerEmail());
            preparedStatement.setString(8, reservation.getCustomerPhone());
            preparedStatement.setString(9, reservation.getCustomerAddress());
            preparedStatement.setString(10, reservation.getPaymentStatus());
            preparedStatement.setDouble(11, reservation.getTotalPrice());
            preparedStatement.setDouble(12, reservation.getCarPricePerDay());
            preparedStatement.setInt(13, reservation.getTotalDays());
            preparedStatement.setInt(14, reservation.getId());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        }
    }

    public boolean deleteReservation(int id) throws SQLException {
        String sql = "DELETE FROM reservations WHERE id = ?";

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, id);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        }
    }
}
