package carrental.model;

public class Car {
    private int id;
    private String brand;
    private String model;
    private String type;
    private int seats;
    private String transmission;
    private boolean airConditioning;
    private String image;
    private double pricePerDay;
    private String status;

    public Car(int id, String brand, String model, String type, int seats, String transmission, boolean airConditioning, String image, double pricePerDay, String status) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.type = type;
        this.seats = seats;
        this.transmission = transmission;
        this.airConditioning = airConditioning;
        this.image = image;
        this.pricePerDay = pricePerDay;
        this.status = status;
    }

    // Getters and setters
    public int getId() { return id; }
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public String getType() { return type; }
    public int getSeats() { return seats; }
    public String getTransmission() { return transmission; }
    public boolean isAirConditioning() { return airConditioning; }
    public String getImage() { return image; }
    public double getPricePerDay() { return pricePerDay; }
    public String getStatus() { return status; }

    public void setId(int id) { this.id = id; }
    public void setBrand(String brand) { this.brand = brand; }
    public void setModel(String model) { this.model = model; }
    public void setType(String type) { this.type = type; }
    public void setSeats(int seats) { this.seats = seats; }
    public void setTransmission(String transmission) { this.transmission = transmission; }
    public void setAirConditioning(boolean airConditioning) { this.airConditioning = airConditioning; }
    public void setImage(String image) { this.image = image; }
    public void setPricePerDay(double pricePerDay) { this.pricePerDay = pricePerDay; }
    public void setStatus(String status) { this.status = status; }
}
