package carrental.model;

public class DashboardStats {
    private int availableCars;
    private int bookedCars;
    private int totalCustomers;

    public DashboardStats(int availableCars, int bookedCars, int totalCustomers) {
        this.availableCars = availableCars;
        this.bookedCars = bookedCars;
        this.totalCustomers = totalCustomers;
    }

    // Getters and setters
    public int getAvailableCars() { return availableCars; }
    public int getBookedCars() { return bookedCars; }
    public int getTotalCustomers() { return totalCustomers; }

    public void setAvailableCars(int availableCars) { this.availableCars = availableCars; }
    public void setBookedCars(int bookedCars) { this.bookedCars = bookedCars; }
    public void setTotalCustomers(int totalCustomers) { this.totalCustomers = totalCustomers; }
}
