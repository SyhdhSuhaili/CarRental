package carrental.model;

import java.util.Date;

public class Reservation {
    private int id;
    private int carId;
    private String pickupLocation;
    private Date pickupDate;
    private Date dropoffDate;
    private String customerName;
    private String customerIC;
    private String customerEmail;
    private String customerPhone;
    private String customerAddress;
    private String paymentStatus;
    private double totalPrice;
    private double carPricePerDay;
    private int totalDays;

    public Reservation(int id, int carId, String pickupLocation, Date pickupDate, Date dropoffDate,
                       String customerName, String customerIC, String customerEmail, String customerPhone,
                       String customerAddress, String paymentStatus, double totalPrice, double carPricePerDay, int totalDays) {
        this.id = id;
        this.carId = carId;
        this.pickupLocation = pickupLocation;
        this.pickupDate = pickupDate;
        this.dropoffDate = dropoffDate;
        this.customerName = customerName;
        this.customerIC = customerIC;
        this.customerEmail = customerEmail;
        this.customerPhone = customerPhone;
        this.customerAddress = customerAddress;
        this.paymentStatus = paymentStatus;
        this.totalPrice = totalPrice;
        this.carPricePerDay = carPricePerDay;
        this.totalDays = totalDays;
    }

    // Getters and setters
    public int getId() { return id; }
    public int getCarId() { return carId; }
    public String getPickupLocation() { return pickupLocation; }
    public Date getPickupDate() { return pickupDate; }
    public Date getDropoffDate() { return dropoffDate; }
    public String getCustomerName() { return customerName; }
    public String getCustomerIC() { return customerIC; }
    public String getCustomerEmail() { return customerEmail; }
    public String getCustomerPhone() { return customerPhone; }
    public String getCustomerAddress() { return customerAddress; }
    public String getPaymentStatus() { return paymentStatus; }
    public double getTotalPrice() { return totalPrice; }
    public double getCarPricePerDay() { return carPricePerDay; }
    public int getTotalDays() { return totalDays; }

    public void setId(int id) { this.id = id; }
    public void setCarId(int carId) { this.carId = carId; }
    public void setPickupLocation(String pickupLocation) { this.pickupLocation = pickupLocation; }
    public void setPickupDate(Date pickupDate) { this.pickupDate = pickupDate; }
    public void setDropoffDate(Date dropoffDate) { this.dropoffDate = dropoffDate; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public void setCustomerIC(String customerIC) { this.customerIC = customerIC; }
    public void setCustomerEmail(String customerEmail) { this.customerEmail = customerEmail; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }
    public void setCustomerAddress(String customerAddress) { this.customerAddress = customerAddress; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public void setCarPricePerDay(double carPricePerDay) { this.carPricePerDay = carPricePerDay; }
    public void setTotalDays(int totalDays) { this.totalDays = totalDays; }
}
