$(document).ready(function() {
    let currentIndex = 0;
    const items = $('.carousel-item');
    const totalItems = items.length;

    function showSlide(index) {
        items.removeClass('active');
        items.eq(index).addClass('active');
    }

    function nextSlide() {
        currentIndex = (currentIndex + 1) % totalItems;
        showSlide(currentIndex);
    }

    function prevSlide() {
        currentIndex = (currentIndex - 1 + totalItems) % totalItems;
        showSlide(currentIndex);
    }

    $('.carousel-control-next').click(function() {
        nextSlide();
    });

    $('.carousel-control-prev').click(function() {
        prevSlide();
    });

    // Auto-slide every 5 seconds
    setInterval(nextSlide, 5000);

    // Initialize the first slide
    showSlide(currentIndex);
    
    // Handle Reserve Now button clicks
    $('.reserve-now').click(function() {
        const carBrand = $(this).data('car-brand');
        window.location.href = `reservation.jsp?carBrand=${carBrand}`;
    });
});
document.addEventListener('DOMContentLoaded', function() {
    const reserveButtons = document.querySelectorAll('.reserve-now');
    reserveButtons.forEach(button => {
        button.addEventListener('click', function() {
            const carBrand = button.getAttribute('data-car-brand');
            let carModel = carBrand.split(' ')[1];
            carBrand = carBrand.split(' ')[0];
            let carPricePerDay;
            switch (carModel) {
                case 'Alphard':
                    carPricePerDay = 900;
                    break;
                case 'X50':
                    carPricePerDay = 550;
                    break;
                case '2':
                    carPricePerDay = 500;
                    break;
                default:
                    carPricePerDay = 0;
            }
            const carImage = button.parentElement.parentElement.querySelector('img').src;
            const pickupLocation = "YourLocation"; // This should be set dynamically if available
            const pickupDate = "YYYY-MM-DD"; // This should be set dynamically if available
            const dropoffDate = "YYYY-MM-DD"; // This should be set dynamically if available

            window.location.href = `reservation.jsp?carBrand=${carBrand}&carModel=${carModel}&carPricePerDay=${carPricePerDay}&carImage=${carImage}&pickupLocation=${pickupLocation}&pickupDate=${pickupDate}&dropoffDate=${dropoffDate}`;
        });
    });
});
